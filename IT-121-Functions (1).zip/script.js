// add validatedPassword function here
function validatedPassword(password){
  if(paasword.lenght <$0);
}